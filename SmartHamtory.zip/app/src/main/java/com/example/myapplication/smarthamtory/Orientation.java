package com.example.myapplication.smarthamtory;

import com.journeyapps.barcodescanner.CaptureActivity;

public class Orientation extends CaptureActivity {
}
