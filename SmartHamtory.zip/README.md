# SmartHamtory

RFCOMM 프로파일을 통해 스마트폰과 메시지를 주고받기 위해 SPP(serial port profile) 서비스를 등록하고 RFCOMM 프로그램을 통해 장치가 연결되기를 기다린다. 

명령어 : sudo sdptool add sp

app이 최신 버전 앱은 아님


블루투스 4.2로 안드로이드 앱과 통신
